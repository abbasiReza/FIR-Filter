/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "D:/Hardware Description Languages/HomeWork/project_1/filter.v";
static unsigned int ng1[] = {26U, 0U};
static int ng2[] = {0, 0};
static unsigned int ng3[] = {270U, 0U};
static int ng4[] = {1, 0};
static unsigned int ng5[] = {963U, 0U};
static int ng6[] = {2, 0};
static unsigned int ng7[] = {2424U, 0U};
static int ng8[] = {3, 0};
static unsigned int ng9[] = {4869U, 0U};
static int ng10[] = {4, 0};
static unsigned int ng11[] = {8259U, 0U};
static int ng12[] = {5, 0};
static unsigned int ng13[] = {12194U, 0U};
static int ng14[] = {6, 0};
static unsigned int ng15[] = {15948U, 0U};
static int ng16[] = {7, 0};
static unsigned int ng17[] = {18666U, 0U};
static int ng18[] = {8, 0};
static unsigned int ng19[] = {19660U, 0U};
static int ng20[] = {9, 0};
static int ng21[] = {19, 0};
static int ng22[] = {18, 0};
static int ng23[] = {0, 0, 0, 0};
static int ng24[] = {10, 0};



static int sp_rs(char *t1, char *t2)
{
    char t12[16];
    char t13[16];
    int t0;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;
    char *t14;

LAB0:    t0 = 1;
    xsi_set_current_line(8, ng0);
    t3 = (t1 + 3000);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    t6 = (t1 + 3160);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t9 = (t1 + 3320);
    t10 = (t9 + 56U);
    t11 = *((char **)t10);
    xsi_vlog_signed_multiply(t12, 36, t8, 16, t11, 16);
    xsi_vlog_signed_add(t13, 36, t5, 36, t12, 36);
    t14 = (t1 + 2840);
    xsi_vlogvar_assign_value(t14, t13, 0, 0, 36);
    t0 = 0;

LAB1:    return t0;
}

static void Initial_17_0(char *t0)
{
    char t3[8];
    char t4[8];
    char *t1;
    char *t2;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;
    char *t12;
    unsigned int t13;
    int t14;
    char *t15;
    unsigned int t16;
    int t17;
    int t18;
    unsigned int t19;
    unsigned int t20;
    int t21;
    int t22;

LAB0:    xsi_set_current_line(17, ng0);

LAB2:    xsi_set_current_line(18, ng0);
    t1 = ((char*)((ng1)));
    t2 = (t0 + 2360);
    t5 = (t0 + 2360);
    t6 = (t5 + 72U);
    t7 = *((char **)t6);
    t8 = (t0 + 2360);
    t9 = (t8 + 64U);
    t10 = *((char **)t9);
    t11 = ((char*)((ng2)));
    xsi_vlog_generic_convert_array_indices(t3, t4, t7, t10, 1, 1, t11, 32, 1);
    t12 = (t3 + 4);
    t13 = *((unsigned int *)t12);
    t14 = (!(t13));
    t15 = (t4 + 4);
    t16 = *((unsigned int *)t15);
    t17 = (!(t16));
    t18 = (t14 && t17);
    if (t18 == 1)
        goto LAB3;

LAB4:    xsi_set_current_line(19, ng0);
    t1 = ((char*)((ng3)));
    t2 = (t0 + 2360);
    t5 = (t0 + 2360);
    t6 = (t5 + 72U);
    t7 = *((char **)t6);
    t8 = (t0 + 2360);
    t9 = (t8 + 64U);
    t10 = *((char **)t9);
    t11 = ((char*)((ng4)));
    xsi_vlog_generic_convert_array_indices(t3, t4, t7, t10, 1, 1, t11, 32, 1);
    t12 = (t3 + 4);
    t13 = *((unsigned int *)t12);
    t14 = (!(t13));
    t15 = (t4 + 4);
    t16 = *((unsigned int *)t15);
    t17 = (!(t16));
    t18 = (t14 && t17);
    if (t18 == 1)
        goto LAB5;

LAB6:    xsi_set_current_line(20, ng0);
    t1 = ((char*)((ng5)));
    t2 = (t0 + 2360);
    t5 = (t0 + 2360);
    t6 = (t5 + 72U);
    t7 = *((char **)t6);
    t8 = (t0 + 2360);
    t9 = (t8 + 64U);
    t10 = *((char **)t9);
    t11 = ((char*)((ng6)));
    xsi_vlog_generic_convert_array_indices(t3, t4, t7, t10, 1, 1, t11, 32, 1);
    t12 = (t3 + 4);
    t13 = *((unsigned int *)t12);
    t14 = (!(t13));
    t15 = (t4 + 4);
    t16 = *((unsigned int *)t15);
    t17 = (!(t16));
    t18 = (t14 && t17);
    if (t18 == 1)
        goto LAB7;

LAB8:    xsi_set_current_line(21, ng0);
    t1 = ((char*)((ng7)));
    t2 = (t0 + 2360);
    t5 = (t0 + 2360);
    t6 = (t5 + 72U);
    t7 = *((char **)t6);
    t8 = (t0 + 2360);
    t9 = (t8 + 64U);
    t10 = *((char **)t9);
    t11 = ((char*)((ng8)));
    xsi_vlog_generic_convert_array_indices(t3, t4, t7, t10, 1, 1, t11, 32, 1);
    t12 = (t3 + 4);
    t13 = *((unsigned int *)t12);
    t14 = (!(t13));
    t15 = (t4 + 4);
    t16 = *((unsigned int *)t15);
    t17 = (!(t16));
    t18 = (t14 && t17);
    if (t18 == 1)
        goto LAB9;

LAB10:    xsi_set_current_line(22, ng0);
    t1 = ((char*)((ng9)));
    t2 = (t0 + 2360);
    t5 = (t0 + 2360);
    t6 = (t5 + 72U);
    t7 = *((char **)t6);
    t8 = (t0 + 2360);
    t9 = (t8 + 64U);
    t10 = *((char **)t9);
    t11 = ((char*)((ng10)));
    xsi_vlog_generic_convert_array_indices(t3, t4, t7, t10, 1, 1, t11, 32, 1);
    t12 = (t3 + 4);
    t13 = *((unsigned int *)t12);
    t14 = (!(t13));
    t15 = (t4 + 4);
    t16 = *((unsigned int *)t15);
    t17 = (!(t16));
    t18 = (t14 && t17);
    if (t18 == 1)
        goto LAB11;

LAB12:    xsi_set_current_line(23, ng0);
    t1 = ((char*)((ng11)));
    t2 = (t0 + 2360);
    t5 = (t0 + 2360);
    t6 = (t5 + 72U);
    t7 = *((char **)t6);
    t8 = (t0 + 2360);
    t9 = (t8 + 64U);
    t10 = *((char **)t9);
    t11 = ((char*)((ng12)));
    xsi_vlog_generic_convert_array_indices(t3, t4, t7, t10, 1, 1, t11, 32, 1);
    t12 = (t3 + 4);
    t13 = *((unsigned int *)t12);
    t14 = (!(t13));
    t15 = (t4 + 4);
    t16 = *((unsigned int *)t15);
    t17 = (!(t16));
    t18 = (t14 && t17);
    if (t18 == 1)
        goto LAB13;

LAB14:    xsi_set_current_line(24, ng0);
    t1 = ((char*)((ng13)));
    t2 = (t0 + 2360);
    t5 = (t0 + 2360);
    t6 = (t5 + 72U);
    t7 = *((char **)t6);
    t8 = (t0 + 2360);
    t9 = (t8 + 64U);
    t10 = *((char **)t9);
    t11 = ((char*)((ng14)));
    xsi_vlog_generic_convert_array_indices(t3, t4, t7, t10, 1, 1, t11, 32, 1);
    t12 = (t3 + 4);
    t13 = *((unsigned int *)t12);
    t14 = (!(t13));
    t15 = (t4 + 4);
    t16 = *((unsigned int *)t15);
    t17 = (!(t16));
    t18 = (t14 && t17);
    if (t18 == 1)
        goto LAB15;

LAB16:    xsi_set_current_line(25, ng0);
    t1 = ((char*)((ng15)));
    t2 = (t0 + 2360);
    t5 = (t0 + 2360);
    t6 = (t5 + 72U);
    t7 = *((char **)t6);
    t8 = (t0 + 2360);
    t9 = (t8 + 64U);
    t10 = *((char **)t9);
    t11 = ((char*)((ng16)));
    xsi_vlog_generic_convert_array_indices(t3, t4, t7, t10, 1, 1, t11, 32, 1);
    t12 = (t3 + 4);
    t13 = *((unsigned int *)t12);
    t14 = (!(t13));
    t15 = (t4 + 4);
    t16 = *((unsigned int *)t15);
    t17 = (!(t16));
    t18 = (t14 && t17);
    if (t18 == 1)
        goto LAB17;

LAB18:    xsi_set_current_line(26, ng0);
    t1 = ((char*)((ng17)));
    t2 = (t0 + 2360);
    t5 = (t0 + 2360);
    t6 = (t5 + 72U);
    t7 = *((char **)t6);
    t8 = (t0 + 2360);
    t9 = (t8 + 64U);
    t10 = *((char **)t9);
    t11 = ((char*)((ng18)));
    xsi_vlog_generic_convert_array_indices(t3, t4, t7, t10, 1, 1, t11, 32, 1);
    t12 = (t3 + 4);
    t13 = *((unsigned int *)t12);
    t14 = (!(t13));
    t15 = (t4 + 4);
    t16 = *((unsigned int *)t15);
    t17 = (!(t16));
    t18 = (t14 && t17);
    if (t18 == 1)
        goto LAB19;

LAB20:    xsi_set_current_line(27, ng0);
    t1 = ((char*)((ng19)));
    t2 = (t0 + 2360);
    t5 = (t0 + 2360);
    t6 = (t5 + 72U);
    t7 = *((char **)t6);
    t8 = (t0 + 2360);
    t9 = (t8 + 64U);
    t10 = *((char **)t9);
    t11 = ((char*)((ng20)));
    xsi_vlog_generic_convert_array_indices(t3, t4, t7, t10, 1, 1, t11, 32, 1);
    t12 = (t3 + 4);
    t13 = *((unsigned int *)t12);
    t14 = (!(t13));
    t15 = (t4 + 4);
    t16 = *((unsigned int *)t15);
    t17 = (!(t16));
    t18 = (t14 && t17);
    if (t18 == 1)
        goto LAB21;

LAB22:
LAB1:    return;
LAB3:    t19 = *((unsigned int *)t3);
    t20 = *((unsigned int *)t4);
    t21 = (t19 - t20);
    t22 = (t21 + 1);
    xsi_vlogvar_assign_value(t2, t1, 0, *((unsigned int *)t4), t22);
    goto LAB4;

LAB5:    t19 = *((unsigned int *)t3);
    t20 = *((unsigned int *)t4);
    t21 = (t19 - t20);
    t22 = (t21 + 1);
    xsi_vlogvar_assign_value(t2, t1, 0, *((unsigned int *)t4), t22);
    goto LAB6;

LAB7:    t19 = *((unsigned int *)t3);
    t20 = *((unsigned int *)t4);
    t21 = (t19 - t20);
    t22 = (t21 + 1);
    xsi_vlogvar_assign_value(t2, t1, 0, *((unsigned int *)t4), t22);
    goto LAB8;

LAB9:    t19 = *((unsigned int *)t3);
    t20 = *((unsigned int *)t4);
    t21 = (t19 - t20);
    t22 = (t21 + 1);
    xsi_vlogvar_assign_value(t2, t1, 0, *((unsigned int *)t4), t22);
    goto LAB10;

LAB11:    t19 = *((unsigned int *)t3);
    t20 = *((unsigned int *)t4);
    t21 = (t19 - t20);
    t22 = (t21 + 1);
    xsi_vlogvar_assign_value(t2, t1, 0, *((unsigned int *)t4), t22);
    goto LAB12;

LAB13:    t19 = *((unsigned int *)t3);
    t20 = *((unsigned int *)t4);
    t21 = (t19 - t20);
    t22 = (t21 + 1);
    xsi_vlogvar_assign_value(t2, t1, 0, *((unsigned int *)t4), t22);
    goto LAB14;

LAB15:    t19 = *((unsigned int *)t3);
    t20 = *((unsigned int *)t4);
    t21 = (t19 - t20);
    t22 = (t21 + 1);
    xsi_vlogvar_assign_value(t2, t1, 0, *((unsigned int *)t4), t22);
    goto LAB16;

LAB17:    t19 = *((unsigned int *)t3);
    t20 = *((unsigned int *)t4);
    t21 = (t19 - t20);
    t22 = (t21 + 1);
    xsi_vlogvar_assign_value(t2, t1, 0, *((unsigned int *)t4), t22);
    goto LAB18;

LAB19:    t19 = *((unsigned int *)t3);
    t20 = *((unsigned int *)t4);
    t21 = (t19 - t20);
    t22 = (t21 + 1);
    xsi_vlogvar_assign_value(t2, t1, 0, *((unsigned int *)t4), t22);
    goto LAB20;

LAB21:    t19 = *((unsigned int *)t3);
    t20 = *((unsigned int *)t4);
    t21 = (t19 - t20);
    t22 = (t21 + 1);
    xsi_vlogvar_assign_value(t2, t1, 0, *((unsigned int *)t4), t22);
    goto LAB22;

}

static void Initial_30_1(char *t0)
{
    char t5[8];
    char t14[8];
    char t15[8];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t6;
    unsigned int t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    char *t12;
    char *t13;
    char *t16;
    char *t17;
    char *t18;
    char *t19;
    char *t20;
    char *t21;
    char *t22;
    char *t23;
    char *t24;
    char *t25;
    unsigned int t26;
    int t27;
    char *t28;
    unsigned int t29;
    int t30;
    int t31;
    unsigned int t32;
    unsigned int t33;
    int t34;
    int t35;

LAB0:    xsi_set_current_line(30, ng0);

LAB2:    xsi_set_current_line(31, ng0);
    xsi_set_current_line(31, ng0);
    t1 = ((char*)((ng2)));
    t2 = (t0 + 2680);
    xsi_vlogvar_assign_value(t2, t1, 0, 0, 32);

LAB3:    t1 = (t0 + 2680);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = ((char*)((ng21)));
    memset(t5, 0, 8);
    xsi_vlog_signed_less(t5, 32, t3, 32, t4, 32);
    t6 = (t5 + 4);
    t7 = *((unsigned int *)t6);
    t8 = (~(t7));
    t9 = *((unsigned int *)t5);
    t10 = (t9 & t8);
    t11 = (t10 != 0);
    if (t11 > 0)
        goto LAB4;

LAB5:
LAB1:    return;
LAB4:    xsi_set_current_line(32, ng0);
    t12 = ((char*)((ng2)));
    t13 = (t0 + 2200);
    t16 = (t0 + 2200);
    t17 = (t16 + 72U);
    t18 = *((char **)t17);
    t19 = (t0 + 2200);
    t20 = (t19 + 64U);
    t21 = *((char **)t20);
    t22 = (t0 + 2680);
    t23 = (t22 + 56U);
    t24 = *((char **)t23);
    xsi_vlog_generic_convert_array_indices(t14, t15, t18, t21, 1, 1, t24, 32, 1);
    t25 = (t14 + 4);
    t26 = *((unsigned int *)t25);
    t27 = (!(t26));
    t28 = (t15 + 4);
    t29 = *((unsigned int *)t28);
    t30 = (!(t29));
    t31 = (t27 && t30);
    if (t31 == 1)
        goto LAB6;

LAB7:    xsi_set_current_line(31, ng0);
    t1 = (t0 + 2680);
    t2 = (t1 + 56U);
    t3 = *((char **)t2);
    t4 = ((char*)((ng4)));
    memset(t5, 0, 8);
    xsi_vlog_signed_add(t5, 32, t3, 32, t4, 32);
    t6 = (t0 + 2680);
    xsi_vlogvar_assign_value(t6, t5, 0, 0, 32);
    goto LAB3;

LAB6:    t32 = *((unsigned int *)t14);
    t33 = *((unsigned int *)t15);
    t34 = (t32 - t33);
    t35 = (t34 + 1);
    xsi_vlogvar_assign_value(t13, t12, 0, *((unsigned int *)t15), t35);
    goto LAB7;

}

static void Always_36_2(char *t0)
{
    char t6[8];
    char t16[8];
    char t27[8];
    char t29[8];
    char t30[8];
    char t70[16];
    char t79[16];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    unsigned int t12;
    char *t13;
    char *t14;
    char *t15;
    char *t17;
    char *t18;
    char *t19;
    char *t20;
    char *t21;
    char *t22;
    char *t23;
    char *t24;
    char *t25;
    char *t26;
    char *t28;
    char *t31;
    char *t32;
    char *t33;
    char *t34;
    char *t35;
    char *t36;
    char *t37;
    char *t38;
    char *t39;
    char *t40;
    unsigned int t41;
    int t42;
    char *t43;
    unsigned int t44;
    int t45;
    int t46;
    unsigned int t47;
    unsigned int t48;
    int t49;
    int t50;
    char *t51;
    char *t52;
    char *t53;
    char *t54;
    char *t55;
    char *t56;
    char *t57;
    char *t58;
    char *t59;
    char *t60;
    char *t61;
    char *t62;
    char *t63;
    char *t64;
    char *t65;
    char *t66;
    char *t67;
    char *t68;
    char *t69;
    char *t71;
    char *t72;
    char *t73;
    char *t74;
    char *t75;
    char *t76;
    char *t77;
    char *t78;
    char *t80;
    unsigned int t81;
    unsigned int t82;
    unsigned int t83;

LAB0:    t1 = (t0 + 4736U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(36, ng0);
    t2 = (t0 + 5056);
    *((int *)t2) = 1;
    t3 = (t0 + 4768);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB4;

LAB1:    return;
LAB4:    xsi_set_current_line(36, ng0);

LAB5:    xsi_set_current_line(37, ng0);
    xsi_set_current_line(37, ng0);
    t4 = ((char*)((ng2)));
    t5 = (t0 + 2680);
    xsi_vlogvar_assign_value(t5, t4, 0, 0, 32);

LAB6:    t2 = (t0 + 2680);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = ((char*)((ng22)));
    memset(t6, 0, 8);
    xsi_vlog_signed_less(t6, 32, t4, 32, t5, 32);
    t7 = (t6 + 4);
    t8 = *((unsigned int *)t7);
    t9 = (~(t8));
    t10 = *((unsigned int *)t6);
    t11 = (t10 & t9);
    t12 = (t11 != 0);
    if (t12 > 0)
        goto LAB7;

LAB8:    xsi_set_current_line(40, ng0);
    t2 = (t0 + 1640U);
    t3 = *((char **)t2);
    t2 = (t0 + 2200);
    t4 = (t0 + 2200);
    t5 = (t4 + 72U);
    t7 = *((char **)t5);
    t13 = (t0 + 2200);
    t14 = (t13 + 64U);
    t15 = *((char **)t14);
    t17 = ((char*)((ng22)));
    xsi_vlog_generic_convert_array_indices(t6, t16, t7, t15, 1, 1, t17, 32, 1);
    t18 = (t6 + 4);
    t8 = *((unsigned int *)t18);
    t42 = (!(t8));
    t19 = (t16 + 4);
    t9 = *((unsigned int *)t19);
    t45 = (!(t9));
    t46 = (t42 && t45);
    if (t46 == 1)
        goto LAB12;

LAB13:    xsi_set_current_line(41, ng0);
    t2 = ((char*)((ng23)));
    t3 = (t0 + 2520);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 36);
    xsi_set_current_line(42, ng0);
    xsi_set_current_line(42, ng0);
    t2 = ((char*)((ng2)));
    t3 = (t0 + 2680);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 32);

LAB14:    t2 = (t0 + 2680);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = ((char*)((ng24)));
    memset(t6, 0, 8);
    xsi_vlog_signed_less(t6, 32, t4, 32, t5, 32);
    t7 = (t6 + 4);
    t8 = *((unsigned int *)t7);
    t9 = (~(t8));
    t10 = *((unsigned int *)t6);
    t11 = (t10 & t9);
    t12 = (t11 != 0);
    if (t12 > 0)
        goto LAB15;

LAB16:    xsi_set_current_line(45, ng0);
    xsi_set_current_line(45, ng0);
    t2 = ((char*)((ng4)));
    t3 = (t0 + 2680);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 32);

LAB20:    t2 = (t0 + 2680);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = ((char*)((ng24)));
    memset(t6, 0, 8);
    xsi_vlog_signed_less(t6, 32, t4, 32, t5, 32);
    t7 = (t6 + 4);
    t8 = *((unsigned int *)t7);
    t9 = (~(t8));
    t10 = *((unsigned int *)t6);
    t11 = (t10 & t9);
    t12 = (t11 != 0);
    if (t12 > 0)
        goto LAB21;

LAB22:    xsi_set_current_line(48, ng0);
    t2 = (t0 + 2520);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    memset(t6, 0, 8);
    t5 = (t6 + 4);
    t7 = (t4 + 4);
    t8 = *((unsigned int *)t4);
    t9 = (t8 >> 20);
    *((unsigned int *)t6) = t9;
    t10 = *((unsigned int *)t7);
    t11 = (t10 >> 20);
    *((unsigned int *)t5) = t11;
    t13 = (t4 + 8);
    t14 = (t4 + 12);
    t12 = *((unsigned int *)t13);
    t41 = (t12 << 12);
    t44 = *((unsigned int *)t6);
    *((unsigned int *)t6) = (t44 | t41);
    t47 = *((unsigned int *)t14);
    t48 = (t47 << 12);
    t81 = *((unsigned int *)t5);
    *((unsigned int *)t5) = (t81 | t48);
    t82 = *((unsigned int *)t6);
    *((unsigned int *)t6) = (t82 & 65535U);
    t83 = *((unsigned int *)t5);
    *((unsigned int *)t5) = (t83 & 65535U);
    t15 = (t0 + 2040);
    xsi_vlogvar_assign_value(t15, t6, 0, 0, 16);
    goto LAB2;

LAB7:    xsi_set_current_line(37, ng0);

LAB9:    xsi_set_current_line(38, ng0);
    t13 = (t0 + 2200);
    t14 = (t13 + 56U);
    t15 = *((char **)t14);
    t17 = (t0 + 2200);
    t18 = (t17 + 72U);
    t19 = *((char **)t18);
    t20 = (t0 + 2200);
    t21 = (t20 + 64U);
    t22 = *((char **)t21);
    t23 = (t0 + 2680);
    t24 = (t23 + 56U);
    t25 = *((char **)t24);
    t26 = ((char*)((ng4)));
    memset(t27, 0, 8);
    xsi_vlog_signed_add(t27, 32, t25, 32, t26, 32);
    xsi_vlog_generic_get_array_select_value(t16, 16, t15, t19, t22, 1, 1, t27, 32, 1);
    t28 = (t0 + 2200);
    t31 = (t0 + 2200);
    t32 = (t31 + 72U);
    t33 = *((char **)t32);
    t34 = (t0 + 2200);
    t35 = (t34 + 64U);
    t36 = *((char **)t35);
    t37 = (t0 + 2680);
    t38 = (t37 + 56U);
    t39 = *((char **)t38);
    xsi_vlog_generic_convert_array_indices(t29, t30, t33, t36, 1, 1, t39, 32, 1);
    t40 = (t29 + 4);
    t41 = *((unsigned int *)t40);
    t42 = (!(t41));
    t43 = (t30 + 4);
    t44 = *((unsigned int *)t43);
    t45 = (!(t44));
    t46 = (t42 && t45);
    if (t46 == 1)
        goto LAB10;

LAB11:    xsi_set_current_line(37, ng0);
    t2 = (t0 + 2680);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = ((char*)((ng4)));
    memset(t6, 0, 8);
    xsi_vlog_signed_add(t6, 32, t4, 32, t5, 32);
    t7 = (t0 + 2680);
    xsi_vlogvar_assign_value(t7, t6, 0, 0, 32);
    goto LAB6;

LAB10:    t47 = *((unsigned int *)t29);
    t48 = *((unsigned int *)t30);
    t49 = (t47 - t48);
    t50 = (t49 + 1);
    xsi_vlogvar_assign_value(t28, t16, 0, *((unsigned int *)t30), t50);
    goto LAB11;

LAB12:    t10 = *((unsigned int *)t6);
    t11 = *((unsigned int *)t16);
    t49 = (t10 - t11);
    t50 = (t49 + 1);
    xsi_vlogvar_assign_value(t2, t3, 0, *((unsigned int *)t16), t50);
    goto LAB13;

LAB15:    xsi_set_current_line(43, ng0);
    t13 = (t0 + 2520);
    t14 = (t13 + 56U);
    t15 = *((char **)t14);
    t17 = (t0 + 2200);
    t18 = (t17 + 56U);
    t19 = *((char **)t18);
    t20 = (t0 + 2200);
    t21 = (t20 + 72U);
    t22 = *((char **)t21);
    t23 = (t0 + 2200);
    t24 = (t23 + 64U);
    t25 = *((char **)t24);
    t26 = (t0 + 2680);
    t28 = (t26 + 56U);
    t31 = *((char **)t28);
    xsi_vlog_generic_get_array_select_value(t16, 16, t19, t22, t25, 1, 1, t31, 32, 1);
    t32 = (t0 + 2360);
    t33 = (t32 + 56U);
    t34 = *((char **)t33);
    t35 = (t0 + 2360);
    t36 = (t35 + 72U);
    t37 = *((char **)t36);
    t38 = (t0 + 2360);
    t39 = (t38 + 64U);
    t40 = *((char **)t39);
    t43 = (t0 + 2680);
    t51 = (t43 + 56U);
    t52 = *((char **)t51);
    xsi_vlog_generic_get_array_select_value(t27, 16, t34, t37, t40, 1, 1, t52, 32, 1);
    t53 = (t0 + 4544);
    t54 = (t0 + 848);
    t55 = xsi_create_subprogram_invocation(t53, 0, t0, t54, 0, 0);
    t56 = (t0 + 3000);
    xsi_vlogvar_assign_value(t56, t15, 0, 0, 36);
    t57 = (t0 + 3160);
    xsi_vlogvar_assign_value(t57, t16, 0, 0, 16);
    t58 = (t0 + 3320);
    xsi_vlogvar_assign_value(t58, t27, 0, 0, 16);

LAB17:    t59 = (t0 + 4640);
    t60 = *((char **)t59);
    t61 = (t60 + 80U);
    t62 = *((char **)t61);
    t63 = (t62 + 272U);
    t64 = *((char **)t63);
    t65 = (t64 + 0U);
    t66 = *((char **)t65);
    t42 = ((int  (*)(char *, char *))t66)(t0, t60);
    if (t42 != 0)
        goto LAB19;

LAB18:    t60 = (t0 + 4640);
    t67 = *((char **)t60);
    t60 = (t0 + 2840);
    t68 = (t60 + 56U);
    t69 = *((char **)t68);
    memcpy(t70, t69, 16);
    t71 = (t0 + 848);
    t72 = (t0 + 4544);
    t73 = 0;
    xsi_delete_subprogram_invocation(t71, t67, t0, t72, t73);
    t74 = (t0 + 2520);
    xsi_vlogvar_assign_value(t74, t70, 0, 0, 36);
    xsi_set_current_line(42, ng0);
    t2 = (t0 + 2680);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = ((char*)((ng4)));
    memset(t6, 0, 8);
    xsi_vlog_signed_add(t6, 32, t4, 32, t5, 32);
    t7 = (t0 + 2680);
    xsi_vlogvar_assign_value(t7, t6, 0, 0, 32);
    goto LAB14;

LAB19:    t59 = (t0 + 4736U);
    *((char **)t59) = &&LAB17;
    goto LAB1;

LAB21:    xsi_set_current_line(46, ng0);
    t13 = (t0 + 2520);
    t14 = (t13 + 56U);
    t15 = *((char **)t14);
    t17 = (t0 + 2520);
    t18 = (t17 + 56U);
    t19 = *((char **)t18);
    t20 = (t0 + 2200);
    t21 = (t20 + 56U);
    t22 = *((char **)t21);
    t23 = (t0 + 2200);
    t24 = (t23 + 72U);
    t25 = *((char **)t24);
    t26 = (t0 + 2200);
    t28 = (t26 + 64U);
    t31 = *((char **)t28);
    t32 = (t0 + 2680);
    t33 = (t32 + 56U);
    t34 = *((char **)t33);
    t35 = ((char*)((ng20)));
    memset(t27, 0, 8);
    xsi_vlog_signed_add(t27, 32, t34, 32, t35, 32);
    xsi_vlog_generic_get_array_select_value(t16, 16, t22, t25, t31, 1, 1, t27, 32, 1);
    t36 = (t0 + 2360);
    t37 = (t36 + 56U);
    t38 = *((char **)t37);
    t39 = (t0 + 2360);
    t40 = (t39 + 72U);
    t43 = *((char **)t40);
    t51 = (t0 + 2360);
    t52 = (t51 + 64U);
    t53 = *((char **)t52);
    t54 = ((char*)((ng20)));
    t55 = (t0 + 2680);
    t56 = (t55 + 56U);
    t57 = *((char **)t56);
    memset(t30, 0, 8);
    xsi_vlog_signed_minus(t30, 32, t54, 32, t57, 32);
    xsi_vlog_generic_get_array_select_value(t29, 16, t38, t43, t53, 1, 1, t30, 32, 1);
    t58 = (t0 + 4544);
    t59 = (t0 + 848);
    t60 = xsi_create_subprogram_invocation(t58, 0, t0, t59, 0, 0);
    t61 = (t0 + 3000);
    xsi_vlogvar_assign_value(t61, t19, 0, 0, 36);
    t62 = (t0 + 3160);
    xsi_vlogvar_assign_value(t62, t16, 0, 0, 16);
    t63 = (t0 + 3320);
    xsi_vlogvar_assign_value(t63, t29, 0, 0, 16);

LAB23:    t64 = (t0 + 4640);
    t65 = *((char **)t64);
    t66 = (t65 + 80U);
    t67 = *((char **)t66);
    t68 = (t67 + 272U);
    t69 = *((char **)t68);
    t71 = (t69 + 0U);
    t72 = *((char **)t71);
    t42 = ((int  (*)(char *, char *))t72)(t0, t65);
    if (t42 != 0)
        goto LAB25;

LAB24:    t65 = (t0 + 4640);
    t73 = *((char **)t65);
    t65 = (t0 + 2840);
    t74 = (t65 + 56U);
    t75 = *((char **)t74);
    memcpy(t70, t75, 16);
    t76 = (t0 + 848);
    t77 = (t0 + 4544);
    t78 = 0;
    xsi_delete_subprogram_invocation(t76, t73, t0, t77, t78);
    xsi_vlog_signed_add(t79, 36, t15, 36, t70, 36);
    t80 = (t0 + 2520);
    xsi_vlogvar_assign_value(t80, t79, 0, 0, 36);
    xsi_set_current_line(45, ng0);
    t2 = (t0 + 2680);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = ((char*)((ng4)));
    memset(t6, 0, 8);
    xsi_vlog_signed_add(t6, 32, t4, 32, t5, 32);
    t7 = (t0 + 2680);
    xsi_vlogvar_assign_value(t7, t6, 0, 0, 32);
    goto LAB20;

LAB25:    t64 = (t0 + 4736U);
    *((char **)t64) = &&LAB23;
    goto LAB1;

}


extern void work_m_00000000000953634570_0181864111_init()
{
	static char *pe[] = {(void *)Initial_17_0,(void *)Initial_30_1,(void *)Always_36_2};
	static char *se[] = {(void *)sp_rs};
	xsi_register_didat("work_m_00000000000953634570_0181864111", "isim/test_isim_beh.exe.sim/work/m_00000000000953634570_0181864111.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}
